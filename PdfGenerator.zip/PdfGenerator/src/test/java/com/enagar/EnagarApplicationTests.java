package com.enagar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnagarApplicationTests {

	@Test
	void contextLoads() {
	}

}
