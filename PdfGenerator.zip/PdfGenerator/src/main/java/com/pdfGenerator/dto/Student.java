package com.pdfGenerator.dto;

public class Student {

	private Integer id;
	private String name;
	private String language;
	private Integer marks;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Integer getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Integer getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Student(String name, String language, int marks,int id) {
		this.id=id;
		this.name = name;
		this.language = language;
		this.marks = marks;
	}
	
	
}
