package com.pdfGenerator.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pdfGenerator.PDFGeneratorApplication.PDFGenerator;
import com.pdfGenerator.dto.Student;

@Controller
public class HomePageController {

	
	private PdfDao pdfDao;
	@Autowired
	public HomePageController(PdfDao thepdfDao) {
		this.pdfDao=thepdfDao;
	}
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping(value = "/students",
            produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> customersReport() throws IOException {
        List<Student> students = pdfDao.getData();

        ByteArrayInputStream bis = PDFGenerator.studentPDFReport(students);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=customers.pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
}
