package com.pdfGenerator.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.pdfGenerator.dto.Student;
@Component
public class PdfDao {

	public List<Student> getData(){
		List<Student> studentList=new ArrayList<>();
		studentList.add(new Student("Subodh","JAVA",78,1));
		studentList.add(new Student("Hello","World",80,2));
		studentList.add(new Student("Ramesh","C++",50,3));
		
		return studentList;
	}
}
